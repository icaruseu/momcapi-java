/*!
 * jQuery UI XRX++ Select1
 *
 * Depends:
 *   
 */
(function( $, undefined ) {
	
$.widget( "ui.xrxSelect1", $.ui.xrx, {
	
	_create: function() {
		
		var self = this; 	
		
		self.element.buttonset();
	}
	
});
	
})( jQuery );